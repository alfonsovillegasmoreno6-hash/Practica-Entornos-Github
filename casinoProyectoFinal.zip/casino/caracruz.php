<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "login_casino");

$id = $_SESSION['id'];

$sql = "SELECT saldo FROM usuarios WHERE id=$id";
$resultado = $conn->query($sql);

$usuario = $resultado->fetch_assoc();
$saldo = $usuario['saldo'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Cara o Cruz</title>

<link rel="stylesheet" href="caracruz.css">

</head>

<body>
    <a href="juegos.php" class="volver">⬅ Volver a juegos</a>

<div class="saldo-panel">
    💰 <span id="saldo"><?php echo $saldo; ?></span> €
</div>

<div class="container">
    <h1>🪙 Cara o Cruz</h1>

    <div class="coin" id="moneda">❓</div>

    <input type="number" id="apuesta" placeholder="💸 Apuesta (€)">

    <br>

    <button onclick="jugar('cara')">🙂 Cara</button>
    <button onclick="jugar('cruz')">🦅 Cruz</button>

    <div id="resultado"></div>
</div>

<script>
let saldo = parseInt(document.getElementById("saldo").textContent);

document.getElementById("saldo").textContent = saldo;

fetch("actualizar_saldo.php", {
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "saldo=" + saldo
});

function jugar(eleccionJugador) {

    let apuesta = parseInt(document.getElementById("apuesta").value);

    if (isNaN(apuesta) || apuesta <= 0) {
        alert("Introduce una apuesta válida");
        return;
    }

    saldo = parseInt(document.getElementById("saldo").textContent);

    if (apuesta > saldo) {
        alert("No tienes suficiente saldo");
        return;
    }

    const moneda = Math.floor(Math.random() * 2);
    const resultado = moneda === 0 ? "cara" : "cruz";

    const monedaUI = document.getElementById("moneda");
    const resultadoUI = document.getElementById("resultado");

    resultadoUI.className = "";

    monedaUI.style.transform = "rotateY(1080deg)";

    setTimeout(() => {
        monedaUI.textContent = resultado === "cara" ? "🙂" : "🦅";

        if (eleccionJugador === resultado) {
            resultadoUI.innerHTML = `🎉 ¡Ganaste ${apuesta}€!`;
            resultadoUI.classList.add("ganar");

            saldo += apuesta;
            lanzarConfeti();

        } else {
            resultadoUI.innerHTML = `😢 Perdiste ${apuesta}€`;
            resultadoUI.classList.add("perder");

            saldo -= apuesta;
        }

            document.getElementById("saldo").textContent = saldo;

        fetch("actualizar_saldo.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "saldo=" + saldo
});

    }, 600);
}

function lanzarConfeti() {
    for (let i = 0; i < 30; i++) {
        const confeti = document.createElement("div");
        confeti.classList.add("confeti");

        confeti.style.left = Math.random() * 100 + "vw";
        confeti.style.background = coloresRandom();

        document.body.appendChild(confeti);

        setTimeout(() => confeti.remove(), 2000);
    }
}

function coloresRandom() {
    const colores = ["red", "yellow", "blue", "green", "orange", "pink"];
    return colores[Math.floor(Math.random() * colores.length)];
}
</script>

</body>
</html>