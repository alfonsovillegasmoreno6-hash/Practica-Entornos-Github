<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "login_casino");

$id = $_SESSION['id'];

$sql = "SELECT saldo FROM usuarios WHERE id=$id";
$resultado = $conn->query($sql);

$usuario = $resultado->fetch_assoc();
$saldo = $usuario['saldo'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Selecciona un juego</title>
    <link rel="stylesheet" href="juegos.css">
</head>

<body>

<!-- 💰 PANEL DE SALDO -->
<div class="saldo-panel">
    💰 <span id="saldo"><?php echo $saldo; ?></span> €
    <button onclick="agregarSaldo()">+</button>
</div>

<h1>🎮 Elige un juego</h1>

<div class="contenedor">
    <a href="caracruz.php" class="juego">🕹️ Cara o cruz</a>
    <a href="ruleta.php" class="juego">🎯 Ruleta</a>
    <a href="blackjack.php" class="juego">🃏 Blackjack</a>
</div>

<!-- 💾 SCRIPT SALDO -->
<script>

    let saldo = parseInt(document.getElementById("saldo").textContent);

    function agregarSaldo() {
        let cantidad = prompt("¿Cuánto quieres añadir?");
        cantidad = parseInt(cantidad);

        if (isNaN(cantidad) || cantidad <= 0) {
            alert("Cantidad no válida");
            return;
        }

        saldo += cantidad;

        document.getElementById("saldo").textContent = saldo;

        fetch("actualizar_saldo.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "saldo=" + saldo
        });
    }
</script>

</body>
</html>