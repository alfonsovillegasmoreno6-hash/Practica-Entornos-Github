<!DOCTYPE html>
<html>
<head>
    <title>Login Casino</title>
</head>
<body>

<h1>🎰 LOGIN CASINO 🎰</h1>

<form action="login.php" method="POST">

    Usuario:
    <input type="text" name="usuario" required>
    <br><br>

    Contraseña:
    <input type="password" name="password" required>
    <br><br>

    <button type="submit">Entrar</button>

</form>

</body>
</html>