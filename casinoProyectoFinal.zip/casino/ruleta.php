<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "login_casino");

$id = $_SESSION['id'];

$sql = "SELECT saldo FROM usuarios WHERE id=$id";
$resultado = $conn->query($sql);

$usuario = $resultado->fetch_assoc();
$saldo = $usuario['saldo'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ruleta</title>
<link rel="stylesheet" href="ruleta.css">

<style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: radial-gradient(circle at top, #0b3d2e, #021a14);
    color: white;
    text-align: center;
}

/* saldo */
.saldo-panel {
    position: absolute;
    top: 20px;
    right: 30px;
    background: linear-gradient(145deg, #222, #111);
    border: 2px solid gold;
    border-radius: 12px;
    padding: 10px 15px;
    color: gold;
}

/* contenedor */
#juego {
    margin-top: 30px;
}

/* input */
input, select {
    padding: 10px;
    border-radius: 10px;
    border: none;
    text-align: center;
    margin: 10px;
}

/* botones */
button {
    background: linear-gradient(145deg, #caa74a, #8f6b1d);
    border: none;
    color: white;
    padding: 10px 15px;
    margin: 10px;
    border-radius: 10px;
    cursor: pointer;
}

button:hover {
    transform: scale(1.05);
    box-shadow: 0 0 10px gold;
}

/* resultado */
#resultado {
    margin-top: 20px;
    font-size: 20px;
}
.volver {
    position: absolute;
    top: 20px;
    left: 30px;
    text-decoration: none;
    color: gold;
    background: linear-gradient(145deg, #222, #111);
    border: 2px solid gold;
    padding: 8px 12px;
    border-radius: 10px;
    font-size: 0.9rem;
    box-shadow: 0 0 10px rgba(255, 215, 0, 0.4);
    transition: 0.2s;
}

.volver:hover {
    transform: scale(1.05);
    box-shadow: 0 0 15px gold;
}
</style>

</head>
<body>
<a href="juegos.php" class="volver">⬅ Volver a juegos</a>
<!-- 💰 SALDO -->
<div class="saldo-panel">
    💰 <span id="saldo"><?php echo $saldo; ?></span> €
</div>

<h1>🎯 Ruleta</h1>

<p>Elige un modo de juego:</p>
<button onclick="modoNumero()">Número</button>
<button onclick="modoColor()">Color</button>

<div id="juego"></div>

<h2 id="resultado"></h2>

<script>
// 💰 SALDO GLOBAL

let saldo = parseInt(document.getElementById("saldo").textContent);

document.getElementById("saldo").textContent = saldo;

fetch("actualizar_saldo.php", {
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "saldo=" + saldo
});

// 🎡 GENERAR RESULTADO
function generarResultado() {
    let numeroGanador = Math.floor(Math.random() * 37);
    let colorGanador;

    if (numeroGanador === 0) {
        colorGanador = "verde";
    } else if (numeroGanador % 2 === 0) {
        colorGanador = "rojo";
    } else {
        colorGanador = "negro";
    }

    return { numeroGanador, colorGanador };
}

// 🎯 MODOS
function modoNumero() {
    document.getElementById("juego").innerHTML = `
        <input type="number" id="numero" placeholder="0 - 36">
        <input type="number" id="apuesta" placeholder="💸 Apuesta (€)">
        <br>
        <button onclick="apostarNumero()">Jugar</button>
    `;
}

function modoColor() {
    document.getElementById("juego").innerHTML = `
        <select id="color">
            <option value="rojo">Rojo</option>
            <option value="negro">Negro</option>
        </select>
        <input type="number" id="apuesta" placeholder="💸 Apuesta (€)">
        <br>
        <button onclick="apostarColor()">Jugar</button>
    `;
}

// 💸 VALIDAR APUESTA
function validarApuesta() {
    let apuesta = parseInt(document.getElementById("apuesta").value);

    if (isNaN(apuesta) || apuesta <= 0) {
        alert("Apuesta no válida");
        return null;
    }

    saldo = parseInt(document.getElementById("saldo").textContent);

    if (apuesta > saldo) {
        alert("No tienes suficiente saldo");
        return null;
    }

    return apuesta;
}

// 🎯 APOSTAR NÚMERO
function apostarNumero() {

    let apuesta = validarApuesta();
    if (apuesta === null) return;

    let numeroApostado = parseInt(document.getElementById("numero").value);

    if (numeroApostado < 0 || numeroApostado > 36 || isNaN(numeroApostado)) {
        mostrarResultado("Número no válido");
        return;
    }

    let { numeroGanador, colorGanador } = generarResultado();

    if (numeroApostado === numeroGanador) {
        let ganancia = apuesta * 35;
        saldo += ganancia;
        mostrarResultado(`🎉 ¡Ganaste ${ganancia}€!`, numeroGanador, colorGanador);
    } else {
        saldo -= apuesta;
        mostrarResultado(`😢 Perdiste ${apuesta}€`, numeroGanador, colorGanador);
    }

    actualizarSaldo();
}

// 🎯 APOSTAR COLOR
function apostarColor() {

    let apuesta = validarApuesta();
    if (apuesta === null) return;

    let colorApostado = document.getElementById("color").value;

    let { numeroGanador, colorGanador } = generarResultado();

    if (colorApostado === colorGanador) {
        let ganancia = apuesta;
        saldo += ganancia;
        mostrarResultado(`🎉 ¡Ganaste ${ganancia}€!`, numeroGanador, colorGanador);
    } else {
        saldo -= apuesta;
        mostrarResultado(`😢 Perdiste ${apuesta}€`, numeroGanador, colorGanador);
    }

    actualizarSaldo();
}

// 💰 ACTUALIZAR SALDO
function actualizarSaldo() {
    document.getElementById("saldo").textContent = saldo;

fetch("actualizar_saldo.php", {
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "saldo=" + saldo
});
}

// 📢 RESULTADO
function mostrarResultado(mensaje, numero, color) {
    document.getElementById("resultado").innerHTML = `
        ${mensaje}<br>
        Número ganador: ${numero}<br>
        Color ganador: ${color}
    `;
}
</script>

</body>
</html>