<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "login_casino");

$id = $_SESSION['id'];

$sql = "SELECT saldo FROM usuarios WHERE id=$id";
$resultado = $conn->query($sql);

$usuario = $resultado->fetch_assoc();
$saldo = $usuario['saldo'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Blackjack</title>
<link rel="stylesheet" href="blackjack.css">
</head>
<body>

<a href="juegos.php" class="volver">⬅ Volver a juegos</a>

<!-- 💰 SALDO -->
<div class="saldo-panel">
    💰 <span id="saldo"><?php echo $saldo; ?></span> €
</div>

<div class="container">
    <h1>🃏 Blackjack</h1>

    <!-- 💸 APUESTA -->
    <input type="number" id="apuesta" placeholder="💸 Apuesta (€)">

    <p id="playerScore">Jugador: 0</p>
    <p id="bankScore">Banca: ?</p>

    <button onclick="empezarPartida()">🎮 Empezar</button>
    <button onclick="pedirCarta()">Pedir carta</button>
    <button onclick="plantarse()">Plantarse</button>
    <button onclick="reiniciar()">Reiniciar</button>

    <div id="log"></div>
</div>

<script>
let jugador = 0;
let banca = 0;
let juegoTerminado = false;
let apuestaActual = 0;

// 💰 SALDO GLOBAL
let saldo = parseInt(document.getElementById("saldo").textContent);

// LOG
function log(mensaje) {
    const logDiv = document.getElementById("log");
    logDiv.innerHTML += mensaje + "<br>";
    logDiv.scrollTop = logDiv.scrollHeight;
}

// CARTAS
function cartaRandom() {
    return Math.floor(Math.random() * 11) + 1;
}

// UI
function actualizarUI() {
    document.getElementById("playerScore").innerText = "Jugador: " + jugador;
    document.getElementById("bankScore").innerText =
        juegoTerminado ? "Banca: " + banca : "Banca: ?";
}

// 🎮 EMPEZAR PARTIDA CON APUESTA
function empezarPartida() {

    let apuesta = parseInt(document.getElementById("apuesta").value);

    if (isNaN(apuesta) || apuesta <= 0) {
        alert("Introduce una apuesta válida");
        return;
    }

    if (apuesta > saldo) {
        alert("No tienes suficiente saldo");
        return;
    }

    apuestaActual = apuesta;

    jugador = cartaRandom() + cartaRandom();
    banca = 0;
    juegoTerminado = false;

    document.getElementById("log").innerHTML = "";

    log("🎮 Nueva partida");
    log("💸 Apuesta: " + apuestaActual + "€");
    log("Tu puntuación inicial: " + jugador);

    actualizarUI();
}

// PEDIR CARTA
function pedirCarta() {
    if (juegoTerminado || apuestaActual === 0) return;

    let carta = cartaRandom();
    jugador += carta;

    log("🂡 Sacas: " + carta);
    log("Total jugador: " + jugador);

    if (jugador > 21) {
        log("💥 Te has pasado. Pierdes.");
        saldo -= apuestaActual;
        terminar();
    }

    actualizarUI();
}

// PLANTARSE
function plantarse() {
    if (juegoTerminado || apuestaActual === 0) return;

    log("🧠 Turno de la banca...");

    while (banca < 17) {
        let carta = cartaRandom();
        banca += carta;
        log("🏦 Banca saca: " + carta);
    }

    log("Total banca: " + banca);

    if (banca > 21 || jugador > banca) {
        log("🎉 ¡Has ganado!");
        saldo += apuestaActual;
    } else if (jugador === banca) {
        log("🤝 Empate");
    } else {
        log("😢 Has perdido");
        saldo -= apuestaActual;
    }

    terminar();
}

// FINALIZAR
function terminar() {
    juegoTerminado = true;

    document.getElementById("saldo").textContent = saldo;

    fetch("actualizar_saldo.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "saldo=" + saldo
    });

    actualizarUI();
}

// REINICIAR
function reiniciar() {
    apuestaActual = 0;
    jugador = 0;
    banca = 0;
    juegoTerminado = false;
    document.getElementById("log").innerHTML = "";
    actualizarUI();
}
</script>

</body>
</html>