<?php

session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "login_casino");

if ($conn->connect_error) {
    die("Error conexión: " . $conn->connect_error);
}

$usuario = $_POST['usuario'];
$password = $_POST['password'];

$sql = "SELECT * FROM usuarios
        WHERE usuario='$usuario'
        AND password='$password'";

$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {

    $fila = $resultado->fetch_assoc();

    $_SESSION['usuario'] = $fila['usuario'];
    $_SESSION['id'] = $fila['id'];

    header("Location: juegos.php");
    exit();

} else {

    echo "❌ Usuario o contraseña incorrectos";

}

?>