<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎰 Gamble Paradise 🎰</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

<div class="fondo"></div>
<div class="luces"></div>

<div class="casino-box">

    <!-- 🃏 TU IMAGEN DEL JOKER -->
    <div class="joker-container">
        <img src="poridentidad.png" alt="Joker">
    </div>

    <h1>🎰 GAMBLE PARADISE 🎰</h1>
    <p class="frase">La suerte favorece a los valientes...</p>

    <form action="verificar.php" method="POST">

        <input type="text" name="usuario" placeholder="👤 Usuario" required>

        <input type="password" name="password" placeholder="🔒 Contraseña" required>

        <button type="submit">💸 ENTRAR Y APOSTAR 💸</button>

    </form>

</div>

<canvas id="money"></canvas>

<script>
const canvas = document.getElementById("money");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const bills = [];

for (let i = 0; i < 50; i++) {
    bills.push({
        x: Math.random() * canvas.width,
        y: -Math.random() * canvas.height, // 👈 empiezan fuera, arriba
        speed: 2 + Math.random() * 5,
        size: 20 + Math.random() * 20
    });
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#00ff66";

    bills.forEach(b => {
        ctx.font = b.size + "px Arial";
        ctx.fillText("$", b.x, b.y);

        b.y += b.speed;

        if (b.y > canvas.height) {
         b.y = -b.size;
         b.x = Math.random() * canvas.width;
        }
    });

    requestAnimationFrame(draw);
}

draw();
</script>

</body>
</html>