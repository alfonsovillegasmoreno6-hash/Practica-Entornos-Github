<!DOCTYPE html>
<html>
<head>
    <title>Casino</title>
</head>
<body>

<h1>🎰 BIENVENIDO AL CASINO 🎰</h1>

<p>Has iniciado sesión correctamente.</p>

</body>
</html>