<?php
session_start();

$conn = new mysqli("localhost", "root", "", "login_casino");

if ($conn->connect_error) {
    die("Error conexión");
}

if (!isset($_SESSION['id'])) {
    die("No autorizado");
}

$id = $_SESSION['id'];
$saldo = $_POST['saldo'];

$sql = "UPDATE usuarios SET saldo=$saldo WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "ok";
} else {
    echo "error";
}
?>